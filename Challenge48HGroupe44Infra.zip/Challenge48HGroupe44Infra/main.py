import json
from flask import Flask, redirect, render_template, request
roles = ["user","organisateur","admin"]


app = Flask(__name__)

@app.route('/', methods=['GET','POST'])
def index():
    return render_template('index.html')

@app.route('/user', methods=['GET','POST'])
def home():
    return render_template('user.html', nom='Sacha', list_nom=["Mael","Maxime","Robert"])

@app.route('/events', methods=['GET','POST'])
def event():
    return render_template('events.html')


@app.route('/login', methods=['GET','POST'])
def login():
    with open('users.json', 'r') as file:
        data = json.load(file)
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        for file in data:
            if file == username and data[file][0] == password:
                if data[file][1] == "admin":
                    return redirect('/admin',200)
                if data[file][1] == "user":
                    return redirect('/user',200)
                if data[file][1] == "organisateur":
                    return redirect("/organisateur",200)
    return render_template('login.html')

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    return render_template('admin.html')


@app.route('/register', methods=['GET','POST'])
def register():
    dictionary = {}
    if request.method == "POST":
        username = request.form['username']
        password = request.form['password']
        cpassword = request.form['cpassword']
        role = "user"
        if password != cpassword:
            return render_template('register.html', goodpassword = password == cpassword)
        dictionary[username] = [password, role]
        with open("users.json", "w+") as outfile:
            json.dump(dictionary, outfile)          
    return render_template('register.html')



if __name__ == '__main__':
    app.run(debug=True)
    
